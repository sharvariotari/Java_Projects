package com.user.demo.controller;

import java.io.ByteArrayInputStream;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.user.demo.constraint.ServiceConstraint;
import com.user.demo.request.PdfRequest;
import com.user.demo.service.PdfService;
import com.user.demo.util.CommonUtils;

@RestController
@RequestMapping("api/v1/pdf")
public class PdfController {
	private static final Logger LOGGER = LoggerFactory.getLogger(PdfController.class);

	@Autowired
	PdfService pdfService;

	@GetMapping("createpdf")
	public ResponseEntity<InputStreamResource> createPdf(HttpServletRequest httpServletRequest) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));

		ByteArrayInputStream createdPdf = pdfService.createPdf();
		HttpHeaders http = new HttpHeaders();
		http.add(" Content-Disposition", "inline;file = test.pdf");

		return ResponseEntity.ok().headers(http).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(createdPdf));
	}

	@PostMapping(value = "createpdfoflaptopp")
	public ResponseEntity<String> generatePdf(@RequestBody PdfRequest pdfRequest) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL, CommonUtils.getString("")));
		ResponseEntity<String> response = null;
		try {
			Boolean pdf = pdfService.generatePdfFile(pdfRequest);
//			Boolean pdf = productinformationService.generatePdfFile();
			if (pdf) {
				response = new ResponseEntity<>(ServiceConstraint.PDF_CREATED_SUCCESSFULLY, HttpStatus.OK);
			} else {
				response = new ResponseEntity<>(ServiceConstraint.FAILED_TO_CREATE_PDF, HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			response = new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		LOGGER.info(String.format(ServiceConstraint.RESPONSE, CommonUtils.getString(response)));
		return response;
	}

	@PostMapping(value = "read", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_MIXED_VALUE,
			MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.APPLICATION_OCTET_STREAM_VALUE })
	public ResponseEntity<String> ReadingDataFromFile(@RequestPart MultipartFile multipartFile) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL, CommonUtils.getString("")));
		ResponseEntity<String> response = null;
		try {
			Boolean readData = pdfService.readFileData(multipartFile);
			if (readData) {
				response = new ResponseEntity<>(ServiceConstraint.DATA_READ_SUCCESSFULLY, HttpStatus.OK);
			} else {
				response = new ResponseEntity<>(ServiceConstraint.FAILED_TO_READ_DATA, HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			response = new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		LOGGER.info(String.format(ServiceConstraint.RESPONSE, CommonUtils.getString(response)));
		return response;
	}

	@PostMapping(value = "convertToPdf")
	public ResponseEntity<String> convertToHtml(@RequestPart PdfRequest pdfRequest) {
		pdfService.convertToPdf(pdfRequest);
		return null;
	}
}
