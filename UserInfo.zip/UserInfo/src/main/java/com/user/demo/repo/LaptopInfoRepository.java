package com.user.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.user.demo.domain.LaptopInfo;

public interface LaptopInfoRepository extends JpaRepository<LaptopInfo, Integer> {

}
