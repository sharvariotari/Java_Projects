//package com.user.demo.config;
//
//import java.io.IOException;
//
//import javax.servlet.FilterChain;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import com.user.demo.service.JwtUserDetailService;
//
//import io.jsonwebtoken.ExpiredJwtException;
//import io.jsonwebtoken.MalformedJwtException;
//
//public class JwtAuthenticationFilter extends OncePerRequestFilter {
//
//	@Autowired
//	private JwtTokenUtil jwtTokenUtil;
//
//	@Autowired
//	private JwtUserDetailService jwtUserDetailService;
//
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//
//	final String requestTokenHeader = request.getHeader("Authorization");
//		//System.out.println(requestToken);
//
//		String userName = null;
//		String token = null;
//		if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer")) {
//			
//			token = requestTokenHeader.substring(7);
//			try {
//				userName = this.jwtTokenUtil.getUsernameFromToken(token);
//			} catch (IllegalArgumentException e) {
//				System.out.println("unable to get jwt token");
//			} catch (ExpiredJwtException e) {
//				System.out.println("Token is expired");
//			} catch (MalformedJwtException e) {
//				System.out.println("invalid jwt");
//			}
//		} else {
//			System.out.println("jwt token does not start with bearer");
//		}
//
//		// validate token
//		if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//			UserDetails userDetails = this.jwtUserDetailService.loadUserByUsername(userName);
//			
//			if (this.jwtTokenUtil.validateToken(token, userDetails)) {
//				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
//						userDetails, userDetails.getAuthorities(), null);
//				usernamePasswordAuthenticationToken
//						.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//
//				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
//			} else {
//				System.out.println("Invalid jwt token");
//			}
//		} else {
//			System.out.println("username is null or cntext is not null");
//		}
//		filterChain.doFilter(request, response);
//	}
//}