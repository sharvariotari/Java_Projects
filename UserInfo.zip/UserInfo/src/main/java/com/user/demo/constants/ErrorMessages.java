package com.user.demo.constants;

public class ErrorMessages {
	public static final String SOMETHING_WENT_WRONG = "Something went wrong";
	public static final String INVALID_PASSWORD = "Invalid Password";
	public static final String CREDENTIALS_DIDNT_MATCH="Credentials didn't match";
}
