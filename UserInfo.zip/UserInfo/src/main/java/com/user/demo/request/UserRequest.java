package com.user.demo.request;

public class UserRequest {
	private String userName;
	private String userEmail;
	private String userPassword;
	private String reenterPassword;


	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getReenterPassword() {
		return reenterPassword;
	}

	public void setReenterPassword(String reenterPassword) {
		this.reenterPassword = reenterPassword;
	}

	

	@Override
	public String toString() {
		return "UserRequest [userName=" + userName + ", userEmail=" + userEmail + ", userPassword=" + userPassword
				+ ", reenterPassword=" + reenterPassword + "]";
	}

}
