package com.user.demo.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.user.demo.domain.Laptop;

@Repository
public interface LaptopRepository extends JpaRepository<Laptop, Integer>{

	@Query(value = "select * from cashapona.employee_laptop ed where ed.emp_Id=?1 and ed.is_active = 'Y';", nativeQuery = true)
	List<Laptop> findByEmpId(int empId);

	

}
