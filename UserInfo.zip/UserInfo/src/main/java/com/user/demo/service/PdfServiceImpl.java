package com.user.demo.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfWriter;
import com.user.demo.domain.Laptop;
import com.user.demo.domain.LaptopInfo;
import com.user.demo.repo.LaptopInfoRepository;
import com.user.demo.repo.LaptopRepository;
import com.user.demo.request.PdfRequest;
import com.user.demo.util.EmployeeLogger;



@Service
public class PdfServiceImpl implements PdfService {
	private static final Logger LOGGER = LoggerFactory.getLogger(PdfServiceImpl.class);

	@Autowired
	LaptopInfoRepository laptopInfoRepository;
	
	@Autowired
	LaptopRepository  laptopRepository;

	@Override
	public ByteArrayInputStream createPdf() {
		EmployeeLogger.info(LOGGER, "Entry :: Inside PdfServiceImpl :: createPdf():");
		String title = " Testing pdf generator";
		String content = " this is for testing purpose";

		ByteArrayOutputStream outPut = new ByteArrayOutputStream();
		Document document = new Document();
		HeaderFooter footer = new HeaderFooter(true, new Phrase(" page"));
		footer.setAlignment(Element.ALIGN_CENTER);
		footer.setBorderWidthBottom(0);
		document.setFooter(footer);
		PdfWriter.getInstance(document, outPut);
		document.open();
		Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 25);
		Paragraph paragrah = new Paragraph(title, titleFont);
		paragrah.setAlignment(Element.ALIGN_CENTER);
		document.add(paragrah);

		Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 18);
		Paragraph paragrahContent = new Paragraph(content, contentFont);
		// paragrahContent.add(new Chunk("This is loooking amazing"));
		paragrahContent.setAlignment(Element.ALIGN_CENTER);
		document.add(paragrahContent);
		document.close();

		return new ByteArrayInputStream(outPut.toByteArray());
	}

	@Override
	public Boolean generatePdfFile(PdfRequest pdfRequest) {
		boolean flag = false;
		try (FileOutputStream file = new FileOutputStream(pdfRequest.getFileName())) {
			Document document = new Document();
			PdfWriter.getInstance(document, file);
			document.open();
			List<Laptop> laptop = laptopRepository.findAll();
			for (Laptop lap : laptop) {
				document.add(new Paragraph("LaptopModel: " + lap.getLaptopId()));
				document.add(new Paragraph("LaptopModel: " + lap.getLaptopModel()));
				document.add(new Paragraph("LaptopPrice: " + lap.getLaptopPrice()));
				//document.add(new Paragraph("LaptopPrice: " + lap.getEmployee()));
				document.add(new Paragraph("\n"));
			}
			document.close();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public Boolean readFileData(MultipartFile multipartFile) {
		Boolean flag = false;
		String extension = StringUtils.getFilenameExtension(multipartFile.getOriginalFilename());

		File file = convertMultiPartFileToFile(multipartFile);
		try (BufferedReader reader = getFileReader(file)) {
			if ("txt".equalsIgnoreCase(extension)) {
				flag = readTxtFileData(reader);
			} else {
				flag = readCsvFileData(reader);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return flag;
	}

	private BufferedReader getFileReader(File file) throws FileNotFoundException {
		Reader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);
		return new BufferedReader(reader);
	}

	private Boolean readTxtFileData(BufferedReader reader) {
		Boolean flag = false;
		String line;
		try {
			while ((line = reader.readLine()) != null) {
				LaptopInfo laptop = new LaptopInfo();
				String[] data = line.split("//");
				laptop.setLaptopName(data[1]);
				laptop.setLaptopPrice(data[2]);
				laptop.setLaptopType(data[3]);
				laptopInfoRepository.save(laptop);
				flag = true;
			}
		} catch (IOException e) {
			flag = false;
			LOGGER.error(e.getMessage(), e);
		}
		return flag;
	}

	private Boolean readCsvFileData(BufferedReader reader) {

		String line;
		Boolean flag = false;
		try {
			while ((line = reader.readLine()) != null) {
				LaptopInfo laptop = new LaptopInfo();
				String[] data = line.split(",");
				laptop.setLaptopName(data[1]);
				laptop.setLaptopPrice(data[2]);
				laptop.setLaptopType(data[3]);
				laptopInfoRepository.save(laptop);
				flag = true;
			}
		} catch (IOException e) {
			flag = false;
			LOGGER.error(e.getMessage(), e);
		}
		return flag;
	}

	private File convertMultiPartFileToFile(MultipartFile multipartFile) {
		File file = new File(multipartFile.getOriginalFilename());
		try (FileOutputStream outputStream = new FileOutputStream(file)) {
			outputStream.write(multipartFile.getBytes());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return file;
	}

	@Override
	public void convertToPdf(PdfRequest pdfRequest) {
//		File htmlFile = new File(pdfRequest.getFileName());
//        org.jsoup.nodes.Document doc = Jsoup.parse(htmlFile,"UTF-8");
//        doc.outputSettings().syntax(Document.OutputSettings.Syntax.xml);
//        try (OutputStream os = new FileOutputStream("/home/demo/Documents/html2pdf/output.pdf")){
//        	ITextRenderer renderer = new ITextRenderer();
//        	SharedContext cntxt = renderer.getSharedContext();
//        	cntxt.setPrint(true);
//        	cntxt.setInteractive(false);
//        	String baseUrl = FileSystems.getDefault().getPath("/home/demo/Documents/html2pdf")
//        			         .toUri().toURL().toString();
//        	renderer.setDocumentFromString(doc.html(), baseUrl);
//        	renderer.layout();
//        	renderer.createPDF(os);
//        	System.out.println("done");
//        }
		
	}
}
