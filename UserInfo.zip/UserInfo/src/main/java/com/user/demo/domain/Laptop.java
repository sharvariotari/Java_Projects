package com.user.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "employee_laptop")
public class Laptop extends EntityAudit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "laptop_id")
	private int laptopId;

	@ManyToOne
	@JoinColumn(name = "emp_id")
	private Employee employee;

	@Column(name = "laptop_model")
	private String laptopModel;

	@Column(name = "laptop_price")
	private String laptopPrice;

	public int getLaptopId() {
		return laptopId;
	}

	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}

	public String getLaptopModel() {
		return laptopModel;
	}

	public void setLaptopModel(String laptopModel) {
		this.laptopModel = laptopModel;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getLaptopPrice() {
		return laptopPrice;
	}

	public void setLaptopPrice(String laptopPrice) {
		this.laptopPrice = laptopPrice;
	}

	@Override
	public String toString() {
		return "Laptop [laptopId=" + laptopId + ", employee=" + employee + ", laptopModel=" + laptopModel
				+ ", laptopPrice=" + laptopPrice + "]";
	}

}
