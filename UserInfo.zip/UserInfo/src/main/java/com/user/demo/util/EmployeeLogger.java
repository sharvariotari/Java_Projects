package com.user.demo.util;

import org.slf4j.Logger;

public class EmployeeLogger {
	public static void error(Logger LOGGER, String errorCode, String errorMessage, Throwable throwable) {
		LOGGER.error(errorCode + "-" + errorMessage, throwable);
	}

	public static void info(Logger LOGGER, String message) {
		LOGGER.debug("Info :: " + message);
	}

	public static void request(Logger LOGGER, Object request) {
		LOGGER.debug("Request :: " + request);
	}

	public static void response(Logger LOGGER, Object response) {
		LOGGER.debug("Response :: " + response);
	}
}
