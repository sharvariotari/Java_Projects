package com.user.demo.request;

public class PdfRequest {
private String fileName;
	

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "PdfRequest [fileName=" + fileName + "]";
	}
}
