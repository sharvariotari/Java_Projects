package com.user.demo.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.user.demo.constraint.FieldNameConstraint;
import com.user.demo.constraint.ServiceConstraint;
import com.user.demo.domain.Employee;
import com.user.demo.domain.Laptop;
import com.user.demo.repo.EmployeeRepository;
import com.user.demo.repo.LaptopRepository;
import com.user.demo.request.EmployeeEmailRequest;
import com.user.demo.request.EmployeeRequest;
import com.user.demo.request.EmployeeSearchRequest;
import com.user.demo.request.LaptopRequest;
import com.user.demo.response.EmployeeResponse;
import com.user.demo.response.EmployeeSearchDto;
import com.user.demo.response.EmployeeSearchResponse;
import com.user.demo.response.LaptopResponse;
import com.user.demo.response.LaptopResponseList;
import com.user.demo.util.CommonUtils;
import com.user.demo.util.EmployeeLogger;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	@Autowired
	LaptopRepository laptoprepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;
	

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	JavaMailSender javaMailSender;

	@Override
	public Employee saveEmployee(EmployeeRequest employeereq) {
		EmployeeLogger.info(LOGGER, "Entry :: Inside EmployeeServiceImpl :: saveEmployee():" + employeereq);
		Employee employee = null;
		Optional<Employee> optional = employeeRepository.findByEmpId(employeereq.getEmpId());
		if (optional.isPresent()) {
			employee = optional.get();
		} else {
			employee = new Employee();
		}
		BeanUtils.copyProperties(employeereq, employee);
		employee.setIsActive(ServiceConstraint.Y);
		Employee employeeDetails = saveEmployeeLaptopDetails(employeereq, employee);
		Employee saveEmployee = employeeRepository.saveAndFlush(employeeDetails);
		EmployeeLogger.info(LOGGER, "Exit :: Inside EmployeeServiceImpl :: saveEmployee():");
		return saveEmployee;
	}

	private Employee saveEmployeeLaptopDetails(EmployeeRequest employeereq, Employee employee) {
		List<Laptop> laptopList = new ArrayList<>();
		Laptop laptop = null;
		for (LaptopRequest laptopSaveRequest : employeereq.getLaptopRequestList()) {
			laptop = new Laptop();
			laptop.setEmployee(employee);
			laptop.setLaptopId(laptopSaveRequest.getLaptopId());
			laptop.setLaptopModel(laptopSaveRequest.getLaptopModel());
			laptop.setLaptopPrice(laptopSaveRequest.getLaptopPrice());
			laptop.setIsActive(ServiceConstraint.Y);
			laptopList.add(laptop);
		}
		employee.setLaptopList(laptopList);
		return employee;
	}

	@Override
	public EmployeeResponse retrieveEmployeeDetails(int empId) {
		EmployeeLogger.info(LOGGER, "Entry :: Inside EmployeeServiceImpl :: retrieveEmployeeDetails():" + empId);
		Optional<Employee> optional = employeeRepository.findByEmpId(empId);
		EmployeeResponse employeeResponse = null;
		if (optional.isPresent()) {
			Employee employee = optional.get();
			employeeResponse = new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmployeeName(employee.getEmployeeName());
			employeeResponse.setEmployeeEmail(employee.getEmployeeEmail());
			BeanUtils.copyProperties(optional.get(), employeeResponse);
		}
		EmployeeLogger.info(LOGGER,
				"Exit :: Outside EmployeeServiceImpl :: retrieveEmployeeDetails():" + employeeResponse);
		return employeeResponse;
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		boolean flag = false;
		Optional<Employee> optional = employeeRepository.findByEmpId(empId);
		List<Laptop> laptopList = null;

		if (optional.isPresent()) {
			Employee employee = optional.get();
			laptopList = laptoprepository.findByEmpId(empId);
			List<Laptop> ListOflaptop = new ArrayList<>();
			for (Laptop laptop : laptopList) {
				laptop.setIsActive(ServiceConstraint.N);
				ListOflaptop.add(laptop);
			}
			if (CommonUtils.isNotEmpty(laptopList)) {
				laptoprepository.saveAll(ListOflaptop);
				employee.setIsActive(ServiceConstraint.N);
				employeeRepository.saveAndFlush(employee);
				flag = true;
			}
		}
		EmployeeLogger.info(LOGGER, "Exit :: Inside CategoryServiceImpl :: deleteCategoryDetailsById():");
		return flag;
	}

	@Override
	public EmployeeSearchResponse findAllEmployeeDetails(EmployeeSearchRequest employeeSearchRequest) {
		EmployeeLogger.info(LOGGER,
				"Entry :: Inside EmployeeServiceImpl :: findAllEmployeeDetails():" + employeeSearchRequest);
		String getDetailsQuery = "select * from employee_data";
		String countQuery = "select count(*) from employee_data";

		String countResponse = "";
		String offSetQuery = "";
		String queryResponse = "";

		StringBuilder stringBuilder = new StringBuilder();
		EmployeeSearchResponse employeeSearchResponse = new EmployeeSearchResponse();

		if (employeeSearchRequest.getEmployeeName() != null && !employeeSearchRequest.getEmployeeName().isEmpty()) {
			stringBuilder.append(" employee_name like ");
			stringBuilder.append("'");
			stringBuilder.append("%" + employeeSearchRequest.getEmployeeName() + "%");
			stringBuilder.append("'");
			stringBuilder.append("AND");
		}
		if (employeeSearchRequest.getEmployeeEmail() != null && !employeeSearchRequest.getEmployeeEmail().isEmpty()) {
			stringBuilder.append(" employee_email like ");
			stringBuilder.append("'");
			stringBuilder.append("%" + employeeSearchRequest.getEmployeeEmail() + "%");
			stringBuilder.append("'");
			stringBuilder.append("AND");
		}
		if (employeeSearchRequest.getEmployeeAddress() != null
				&& !employeeSearchRequest.getEmployeeAddress().isEmpty()) {
			stringBuilder.append(" employee_address like ");
			stringBuilder.append("'");
			stringBuilder.append("%" + employeeSearchRequest.getEmployeeAddress() + "%");
			stringBuilder.append("'");
			stringBuilder.append("AND");
		}
		int pagecount = employeeSearchRequest.getPage() - 1;
		int offset = pagecount * employeeSearchRequest.getLimit();

		if (!employeeSearchRequest.getOrderBy().isEmpty() && !employeeSearchRequest.getOrderDirection().isEmpty()) {
			if (employeeSearchRequest.getOrderBy().equalsIgnoreCase("employeeName")) {
				offSetQuery = " ORDER BY employee_name " + employeeSearchRequest.getOrderDirection() + " LIMIT "
						+ offset + " , " + employeeSearchRequest.getLimit();
			} else if (employeeSearchRequest.getOrderBy().equalsIgnoreCase("employeeEmail")) {
				offSetQuery = " ORDER BY employee_email " + employeeSearchRequest.getOrderDirection() + " LIMIT "
						+ offset + " ," + employeeSearchRequest.getLimit();
			} else if (employeeSearchRequest.getOrderBy().equalsIgnoreCase("employeeAddress")) {
				offSetQuery = " ORDER BY employee_address " + employeeSearchRequest.getOrderDirection() + " LIMIT "
						+ offset + " ," + employeeSearchRequest.getLimit();
			} else {
				offSetQuery = " order by emp_id asc LIMIT " + offset + "," + employeeSearchRequest.getLimit();
			}
		}
		if (!stringBuilder.isEmpty()) {
			stringBuilder.replace(stringBuilder.length() - 3, stringBuilder.length(), "");
			queryResponse = getDetailsQuery + " where " + stringBuilder + " AND is_active = 'Y' " + " " + offSetQuery;
		} else {
			queryResponse = getDetailsQuery + " where is_active = 'Y' " + " " + offSetQuery;
		}

		if (!stringBuilder.isEmpty()) {
			countResponse = countQuery + " where " + stringBuilder + " AND is_active = 'Y' ";
		} else {
			countResponse = countQuery + " where is_active = 'Y' ";
		}

		List<EmployeeSearchDto> allEmployeeSearchResponse = jdbcTemplate.query(queryResponse,
				(rs, rowNum) -> employeeMapFields(rs));
		int totalCount = jdbcTemplate.queryForObject(countResponse.toString(), Integer.class);

		employeeSearchResponse.setResultObject(allEmployeeSearchResponse);
		employeeSearchResponse.setCount(Long.valueOf(totalCount));
		employeeSearchResponse.setPage(employeeSearchRequest.getPage());
		employeeSearchResponse.setLimit(employeeSearchRequest.getLimit());
		EmployeeLogger.info(LOGGER,
				"Exit :: Inside OutreachServiceImpl :: searchOutreachDetails(): " + employeeSearchResponse);
		return employeeSearchResponse;
	}

	private EmployeeSearchDto employeeMapFields(ResultSet rs) throws SQLException {
		EmployeeSearchDto employeeSearchDto = new EmployeeSearchDto();
		employeeSearchDto.setEmpId(rs.getInt(FieldNameConstraint.EMPLOYEE_ID));
		employeeSearchDto.setEmployeeName(rs.getString(FieldNameConstraint.EMPLOYEE_NAME));
		employeeSearchDto.setEmployeeEmail(rs.getString(FieldNameConstraint.EMPLOYEE_EMAIL));
		employeeSearchDto.setEmployeeAddress(rs.getString(FieldNameConstraint.EMPLOYEE_ADDRESS));
		return employeeSearchDto;
	}

	@Override
	public LaptopResponse retrieveLaptopDetails(int empId) {
		EmployeeLogger.info(LOGGER, "Entry :: Inside EmployeeServiceImpl :: retrieveLaptopDetails():" + empId);
		List<Laptop> laptopList = laptoprepository.findByEmpId(empId);
		LaptopResponse laptopResponse = new LaptopResponse();
		LaptopResponseList laptopResponseList = null;
		List<LaptopResponseList> listOfLaptop = new ArrayList<>();
		Optional<Employee> optional = employeeRepository.findByEmpId(empId);
		if (optional.isPresent()) {
			Employee employee = optional.get();
			laptopResponse.setEmpId(employee.getEmpId());
		}

		for (Laptop laptops : laptopList) {
			laptopResponseList = new LaptopResponseList();
			laptopResponseList.setLaptopId(laptops.getLaptopId());
			laptopResponseList.setLaptopPrice(laptops.getLaptopPrice());
			laptopResponseList.setLaptopModel(laptops.getLaptopModel());
			listOfLaptop.add(laptopResponseList);
		}
		laptopResponse.setLaptopResponseList(listOfLaptop);
		EmployeeLogger.info(LOGGER, "Exit ::Inside EmployeeServiceImpl :: retrieveLaptopDetails():");
		return laptopResponse;
	}

	@Override
	public void sendEmail(EmployeeEmailRequest employeeEmailRequest,MultipartFile [] multipartFile) throws MessagingException{
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message,true);
		helper.setTo(employeeEmailRequest.getEmailTo());
		helper.setSubject(employeeEmailRequest.getSubject());
		helper.setText(employeeEmailRequest.getText());
		
		if (multipartFile != null) {
			for (MultipartFile file : multipartFile) {
				if (file.getSize() > 0) {
					helper.addAttachment(file.getOriginalFilename(), file);
				}
			}
		}
		javaMailSender.send(message);
	}

}
