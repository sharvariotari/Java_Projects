package com.user.demo.request;

import java.util.List;

public class EmployeeRequest {
	private int empId;
	private String employeeName;
	private String employeeEmail;
	private String employeeAddress;
	private List<LaptopRequest> laptopRequestList;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public List<LaptopRequest> getLaptopRequestList() {
		return laptopRequestList;
	}

	public void setLaptopRequestList(List<LaptopRequest> laptopRequestList) {
		this.laptopRequestList = laptopRequestList;
	}

	@Override
	public String toString() {
		return "EmployeeRequest [empId=" + empId + ", employeeName=" + employeeName + ", employeeEmail=" + employeeEmail
				+ ", employeeAddress=" + employeeAddress + ", laptopRequestList=" + laptopRequestList + "]";
	}

}
