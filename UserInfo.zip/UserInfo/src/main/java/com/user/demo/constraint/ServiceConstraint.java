package com.user.demo.constraint;

public class ServiceConstraint {
	
	private ServiceConstraint() {
		
	}
	public static final String Y = "Y";
	public static final String ADMIN = "Admin";
	public static final String N = "N";
	public static final String REQUEST_URL = "API URl : %s";
	public static final String REQUEST = "Request : Payload: %s";
	public static final String RESPONSE = "Response : Payload: %s";
	public static final String SAVE_USER="api/v1/userinfo/save/user";
	public static final String FIND_ALL_USER = "api/v1/userinfo/get/alluser";
	public static final String FIND_ALL_USER_BYGROUPING = "Find all user by grouping";
	public static final String PDF_CREATED_SUCCESSFULLY = "Pdf created successfully";
	public static final String FAILED_TO_CREATE_PDF = "Failed to create pdf";
	public static final String DATA_READ_SUCCESSFULLY = "Data read successfully";
	public static final String FAILED_TO_READ_DATA = "Failed to read data";
}
