package com.user.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.user.demo.domain.DaoUser;

public interface UserDao extends JpaRepository<DaoUser, Integer>{
	DaoUser findByUsername(String username);
}
