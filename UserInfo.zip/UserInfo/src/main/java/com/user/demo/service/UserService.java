package com.user.demo.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.user.demo.domain.User;
import com.user.demo.request.UserRequest;

@Service
public interface UserService {

	public User saveUser(UserRequest userreq);

	public List<User> getAllUser();

	public Map<String, List<User>> getAllUserBygroupName();

	

}
