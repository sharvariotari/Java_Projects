package com.user.demo.response;

public class UserResponse {
	private String userName;
	private String userEmail;
	
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	@Override
	public String toString() {
		return "UserResponse [userName=" + userName + ", userEmail=" + userEmail + "]";
	}
	
	
	
	

}
