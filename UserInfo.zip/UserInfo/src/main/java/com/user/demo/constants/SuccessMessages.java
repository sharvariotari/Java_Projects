package com.user.demo.constants;

public class SuccessMessages {
	public static final String USER_DETAILS_SAVED_SUCCESSFULLY = "User details added successfully";
	public static final String USER_PASSWORD_GENERATED_SUCCESSFULLY="User password generated successfully";
	public static final String SAVED_SUCCESSFULLY = "Saved Successfully";
	public static final String EMPLOYEE_DETAILS_SAVED_SUCCESSFULLY = "Employee details added successfully";
	public static final String EMPLOYEE_DETAILS_DELETED_SUCCESSFULLY =  "Employee details deleted successfully";
	public static final String MAIL_SEND_SUCCESSFULLY = "Email sent successfully";
}
