package com.user.demo.exception;

public class UserException extends RuntimeException{

	
	private static final long serialVersionUID = 1L;

	public UserException(Exception ex) {
		super(ex);
	}
	 @Override
	 public String getMessage() {
	        return "Invalid credentials";
	    }
}
