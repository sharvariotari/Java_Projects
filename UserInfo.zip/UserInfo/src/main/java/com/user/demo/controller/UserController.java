package com.user.demo.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.demo.constants.ErrorMessages;
import com.user.demo.constants.SuccessMessages;
import com.user.demo.constraint.ServiceConstraint;
import com.user.demo.domain.User;
import com.user.demo.exception.UserException;
import com.user.demo.request.UserRequest;
import com.user.demo.response.ResponseObject;
import com.user.demo.service.UserService;
import com.user.demo.util.CommonUtils;

@RestController
@RequestMapping("api/v1/userinfo/")
public class UserController extends BaseController {

	@Autowired
	UserService userservice;

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@PostMapping("save/user")
	public ResponseObject saveUserDetails(@RequestBody UserRequest userreq) {
		LOGGER.info(
				String.format(ServiceConstraint.REQUEST_URL, CommonUtils.getString(ServiceConstraint.SAVE_USER)));
		LOGGER.info(String.format(ServiceConstraint.REQUEST, CommonUtils.getString(userreq)));
		User user = null;
		ResponseObject responseobject = null;
		try {
			user = userservice.saveUser(userreq);

			if (user != null) {
				return new ResponseObject(SuccessMessages.USER_DETAILS_SAVED_SUCCESSFULLY, null, HttpStatus.OK);
			} else {
				responseobject = new ResponseObject(ErrorMessages.CREDENTIALS_DIDNT_MATCH, null,
						HttpStatus.BAD_REQUEST);
			}
		} catch (UserException e) {
			LOGGER.error(e.getMessage(), e);
			responseobject = new ResponseObject(null, e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return responseobject;
	}

	@GetMapping("get/alluser")
	public ResponseObject getAllUserDetails() {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(ServiceConstraint.FIND_ALL_USER)));
		ResponseObject responseobject = getResponse(userservice.getAllUser());
		LOGGER.info(String.format(ServiceConstraint.RESPONSE, CommonUtils.getString(responseobject)));
		return responseobject;
	}

	@GetMapping("get/allstudentsByGrouping")
	public ResponseEntity<?> getAllStudentsByGrouping() {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(ServiceConstraint.FIND_ALL_USER_BYGROUPING)));
		Map<String, List<User>> st = userservice.getAllUserBygroupName();

		return new ResponseEntity<>(st, HttpStatus.OK);
	}

}