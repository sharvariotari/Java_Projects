package com.user.demo.request;

public class EmployeeSearchRequest {

	private String employeeName;
	private String employeeEmail;
	private String employeeAddress;
	private int limit;
	private int page;
	private String orderBy;
	private String orderDirection;
	private static final String DEFAULT_SORT = "Desc";
	private static final int DEFAULT_LIMIT = 10;
	private static final int DEFAULT_PAGE = 1;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public int getLimit() {
		if (limit == 0) {
			limit = DEFAULT_LIMIT;
		}
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPage() {
		if (page == 0) {
			page = DEFAULT_PAGE;
		}
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getOrderBy() {
		if (orderBy == null || orderBy.isEmpty()) {
			orderBy = "id";
		}
		return orderBy;	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrderDirection() {
		if (orderDirection == null || orderDirection.isEmpty()) {
			orderDirection = DEFAULT_SORT;
		}
		return orderDirection;
	}

	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}

	public static String getDefaultSort() {
		return DEFAULT_SORT;
	}

	public static int getDefaultLimit() {
		return DEFAULT_LIMIT;
	}

	public static int getDefaultPage() {
		return DEFAULT_PAGE;
	}

	@Override
	public String toString() {
		return "EmployeeSearchRequest [employeeName=" + employeeName + ", employeeEmail=" + employeeEmail
				+ ", employeeAddress=" + employeeAddress + ", limit=" + limit + ", page=" + page + ", orderBy="
				+ orderBy + ", orderDirection=" + orderDirection + "]";
	}

}
