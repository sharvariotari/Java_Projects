//package com.user.demo.service;
//
//import java.util.ArrayList;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.crypto.password.PasswordEncoder;
//
//import com.user.demo.domain.DaoUser;
//import com.user.demo.repo.UserDao;
//import com.user.demo.request.DaoUserRequest;
//
//
//public class JwtUserDetailService implements UserDetailsService{
//
//
//	@Autowired
//	private UserDao userDao;
//
//	@Autowired
//	private PasswordEncoder bcryptEncoder;
//
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//
//		DaoUser user = userDao.findByUsername(username);
//		if (user == null) {
//			throw new UsernameNotFoundException("User not found with username: " + username);
//		}
//		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
//				new ArrayList<>());
//		
//		//hardcoded data for user login
//		
////		if ("javainuse".equals(username)) {
////			return new User("javainuse", "$2a$10$slYQmyNdGzTn7ZLBXBChFOC9f6kFjAqPhccnP6DxlWXx2lPk1C3G6",
////					new ArrayList<>());
////		} else {
////			throw new UsernameNotFoundException("User not found with username: " + username);
////		}
//	}
//	
//	public DaoUser save(DaoUserRequest user) {
//		DaoUser newUser = new DaoUser();
//		newUser.setUsername(user.getUsername());
//		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
//		return userDao.save(newUser);
//	}
//
//}
