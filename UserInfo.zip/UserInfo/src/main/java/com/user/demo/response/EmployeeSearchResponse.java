package com.user.demo.response;

import java.util.List;

public class EmployeeSearchResponse {
	private Long count;
	private int limit;
	private int page;
	private List<EmployeeSearchDto> resultObject;

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public List<EmployeeSearchDto> getResultObject() {
		return resultObject;
	}

	public void setResultObject(List<EmployeeSearchDto> resultObject) {
		this.resultObject = resultObject;
	}

	@Override
	public String toString() {
		return "EmployeeSearchResponse [count=" + count + ", limit=" + limit + ", page=" + page + ", resultObject="
				+ resultObject + "]";
	}

}
