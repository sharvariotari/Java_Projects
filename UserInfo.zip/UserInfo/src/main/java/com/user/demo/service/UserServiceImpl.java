package com.user.demo.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.demo.domain.User;
import com.user.demo.exception.UserException;
import com.user.demo.repo.UserRepository;
import com.user.demo.request.UserRequest;
import com.user.demo.util.CommonUtils;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	@Autowired
	private UserRepository userrepository;

	@Override
	public User saveUser(UserRequest userReq) {
		LOGGER.info("Entry :: Inside UserService :: saveUserDetails():" + userReq);
		User user = null;
		CommonUtils.generateTempararypassword();
		try {
			if (validatePassword(userReq.getUserPassword(), userReq.getReenterPassword())
					&& CommonUtils.validateEmail(userReq.getUserEmail())) {
				user = new User();
				user.setUserName(userReq.getUserName());
				user.setUserEmail(userReq.getUserEmail());
				user.setUserPassword(userReq.getUserPassword());
				BeanUtils.copyProperties(userReq, user);
				userrepository.save(user);
			}
		} catch (UserException e) {
			e.getMessage();
		}
		return user;
	}

	public static boolean validatePassword(String userPassword, String reenterPassword) {
		boolean flag = false;
		try {
			if (CommonUtils.isNotNull(userPassword) && CommonUtils.isNotNull(reenterPassword)
					&& (userPassword.equals(reenterPassword))) {
				flag = true;
			}
		} catch (UserException e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public List<User> getAllUser() {
		LOGGER.info("Entry :: Inside UserService :: getAllUser():");
		return userrepository.findAll();
	}

	@Override
	public Map<String, List<User>> getAllUserBygroupName() {
		Map<String, List<User>> groupbyname = userrepository.findAll().stream()
				.collect(Collectors.groupingBy(User::getUserName, Collectors.toList()));
		return groupbyname;
	}

}
