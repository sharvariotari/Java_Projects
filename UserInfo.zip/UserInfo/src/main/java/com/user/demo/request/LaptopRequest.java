package com.user.demo.request;

public class LaptopRequest {
	private int laptopId;
	private String laptopModel;
	private String laptopPrice;

	public int getLaptopId() {
		return laptopId;
	}

	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}

	public String getLaptopModel() {
		return laptopModel;
	}

	public void setLaptopModel(String laptopModel) {
		this.laptopModel = laptopModel;
	}

	public String getLaptopPrice() {
		return laptopPrice;
	}

	public void setLaptopPrice(String laptopPrice) {
		this.laptopPrice = laptopPrice;
	}

	@Override
	public String toString() {
		return "LaptopRequest [laptopId=" + laptopId + ", laptopModel=" + laptopModel + ", laptopPrice=" + laptopPrice
				+ "]";
	}

}
