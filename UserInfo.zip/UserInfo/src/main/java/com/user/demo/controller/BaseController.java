package com.user.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.user.demo.domain.User;
import com.user.demo.response.ResponseObject;

public class BaseController {
	public <T> ResponseObject getResponse(T entity) {
		if (entity != null) {
			return new ResponseObject(entity, null, HttpStatus.OK);
		}
		return new ResponseObject(Arrays.asList(), null, HttpStatus.OK);
	}
	public  ResponseObject getResponse(List<User> allUser) {
		if (allUser == null || allUser.isEmpty()) {
			return new ResponseObject(Arrays.asList(), null, HttpStatus.OK);
		}
		return new ResponseObject(allUser, null, HttpStatus.OK);
	}

}
