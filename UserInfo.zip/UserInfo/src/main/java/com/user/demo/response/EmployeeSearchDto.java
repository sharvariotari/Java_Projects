package com.user.demo.response;

public class EmployeeSearchDto {
	private int empId;
	private String employeeName;
	private String employeeEmail;
	private String employeeAddress;

	public EmployeeSearchDto() {
		super();

	}

	public EmployeeSearchDto(int empId, String employeeName, String employeeEmail, String employeeAddress) {
		super();
		this.empId = empId;
		this.employeeName = employeeName;
		this.employeeEmail = employeeEmail;
		this.employeeAddress = employeeAddress;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	@Override
	public String toString() {
		return "EmployeeSearchDto [empId=" + empId + ", employeeName=" + employeeName + ", employeeEmail="
				+ employeeEmail + ", employeeAddress=" + employeeAddress + "]";
	}

}
