package com.user.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "laptop_information")
public class LaptopInfo {

	@Id
	@Column(name = "laptop_id")
	private Long laptopId;

	@Column(name = "laptop_name")
	private String laptopName;

	@Column(name = "laptop_price")
	private String laptopPrice;

	@Column(name = "laptop_type")
	private String laptopType;

	public Long getLaptopId() {
		return laptopId;
	}

	public void setLaptopId(Long laptopId) {
		this.laptopId = laptopId;
	}

	public String getLaptopName() {
		return laptopName;
	}

	public void setLaptopName(String laptopName) {
		this.laptopName = laptopName;
	}

	public String getLaptopPrice() {
		return laptopPrice;
	}

	public void setLaptopPrice(String laptopPrice) {
		this.laptopPrice = laptopPrice;
	}

	public String getLaptopType() {
		return laptopType;
	}

	public void setLaptopType(String laptopType) {
		this.laptopType = laptopType;
	}

	@Override
	public String toString() {
		return "LaptopInfo [laptopId=" + laptopId + ", laptopName=" + laptopName + ", laptopPrice=" + laptopPrice
				+ ", laptopType=" + laptopType + "]";
	}

}
