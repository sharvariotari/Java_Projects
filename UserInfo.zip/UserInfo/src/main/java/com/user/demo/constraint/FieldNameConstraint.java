package com.user.demo.constraint;

public class FieldNameConstraint {
	public static final String EMPLOYEE_ID = "emp_id";
	public static final String EMPLOYEE_NAME = "employee_name";
	public static final String EMPLOYEE_EMAIL= "employee_email";
	public static final String EMPLOYEE_ADDRESS = "employee_address";
}
