package com.user.demo.service;


import javax.mail.MessagingException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.user.demo.domain.Employee;
import com.user.demo.request.EmployeeEmailRequest;
import com.user.demo.request.EmployeeRequest;
import com.user.demo.request.EmployeeSearchRequest;
import com.user.demo.response.EmployeeResponse;
import com.user.demo.response.EmployeeSearchResponse;
import com.user.demo.response.LaptopResponse;

@Service
public interface EmployeeService {
	
	public Employee saveEmployee(EmployeeRequest employeereq);

	EmployeeResponse retrieveEmployeeDetails(int empId);

	public boolean deleteEmployeeById(int empId);

	public EmployeeSearchResponse findAllEmployeeDetails(EmployeeSearchRequest employeeSearchRequest);

	public LaptopResponse retrieveLaptopDetails(int empId);

	public void sendEmail(EmployeeEmailRequest employeeEmailRequest, MultipartFile []multipartFile) throws MessagingException;
}
