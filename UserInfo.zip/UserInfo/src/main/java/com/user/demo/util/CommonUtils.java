package com.user.demo.util;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonUtils {
	private static final String EMAIL_REGEX = "^(.+)@(.+)$";
	private static final String DATE_TIME_FORMAT = "yyyyMMddHHssmm";
	private static final String RANDOM_STRING = "ghjkjhjgfdsadfghjytrcfvgbhnjhgf";

	private static ObjectMapper mapper = new ObjectMapper();

	public CommonUtils() {

	}

	public static boolean isNotNull(String value) {
		return (value != null && value.trim().length() > 0);
	}

	public static boolean isNotEmpty(Collection<?> collection) {
		return collection != null && !collection.isEmpty();
	}

	public static boolean isNull(String value) {
		return (value == null || value.trim().length() == 0);
	}

	public static String getString(Object object) {
		String value = "";
		try {
			value = mapper.writeValueAsString(object);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public static String generateTempararypassword() {
		String temperaryPassword = generateCurrentDate() + getRandomString();
		return temperaryPassword;
	}

	public static boolean validateEmail(String userEmail) {
		Pattern emailPattern = Pattern.compile(EMAIL_REGEX);
		Matcher m = emailPattern.matcher(userEmail);
		return m.matches();
	}

	public static String getRandomString() {
		String alphabet = RANDOM_STRING;
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		int length = 10;
		for (int i = 0; i < length; i++) {
			int index = random.nextInt(alphabet.length());
			char randomChar = alphabet.charAt(index);
			sb.append(randomChar);
		}
		return sb.toString();
	}

	public static String generateCurrentDate() {
		Date date = new Date();
		String modify = new SimpleDateFormat(DATE_TIME_FORMAT).format(date);
		return modify;
	}

}
