package com.user.demo.domain;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import org.hibernate.annotations.CreationTimestamp;
import com.fasterxml.jackson.annotation.JsonIgnore;

@MappedSuperclass
public class EntityAudit {


	@CreationTimestamp
	@JsonIgnore
	@Column(name = "created_date")
	private Date createdDate;

	
	@Column(name = "is_active")
	private String isActive;

	public EntityAudit() {
		super();
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "EntityAudit [createdDate=" + createdDate + ", isActive=" + isActive + "]";
	}


	

}
