package com.user.demo.controller;


import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.user.demo.constants.ErrorMessages;
import com.user.demo.constants.SuccessMessages;
import com.user.demo.constraint.ServiceConstraint;
import com.user.demo.domain.Employee;
import com.user.demo.request.EmployeeEmailRequest;
import com.user.demo.request.EmployeeRequest;
import com.user.demo.request.EmployeeSearchRequest;
import com.user.demo.response.EmployeeResponse;
import com.user.demo.response.EmployeeSearchResponse;
import com.user.demo.response.LaptopResponse;
import com.user.demo.service.EmployeeService;
import com.user.demo.util.CommonUtils;


@RestController
@RequestMapping("api/v1/employeeinfo")
public class EmployeeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	EmployeeService employeeService;

	@PostMapping("save/employeedetail")
	public ResponseEntity<String> saveEmployee(HttpServletRequest httpServletRequest,
			@RequestBody EmployeeRequest employeereq) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));
		LOGGER.info(String.format(ServiceConstraint.REQUEST, CommonUtils.getString(employeereq)));
		Employee employee = null;
		try {
			employee = employeeService.saveEmployee(employeereq);
			if (employee != null) {
				return ResponseEntity.ok(SuccessMessages.EMPLOYEE_DETAILS_SAVED_SUCCESSFULLY);
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorMessages.SOMETHING_WENT_WRONG);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorMessages.SOMETHING_WENT_WRONG);
		}
	}

	@GetMapping("find/employee/{empId}")
	public ResponseEntity<EmployeeResponse> getEmployee(@PathVariable("empId") int empId,
			HttpServletRequest httpServletRequest) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));
		LOGGER.info(String.format(ServiceConstraint.REQUEST, CommonUtils.getString(empId)));
		EmployeeResponse employeeResponse = null;
		employeeResponse = employeeService.retrieveEmployeeDetails(empId);
		if (employeeResponse != null) {
			LOGGER.info(String.format(ServiceConstraint.RESPONSE, CommonUtils.getString(employeeResponse)));
			return new ResponseEntity<>(employeeResponse, HttpStatus.OK);
		} else {
			return new ResponseEntity<EmployeeResponse>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("search/all")
	public ResponseEntity<EmployeeSearchResponse> getAllEmployeeDetails(
			@RequestBody EmployeeSearchRequest employeeSearchRequest, HttpServletRequest httpServletRequest) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));
		LOGGER.info(String.format(ServiceConstraint.REQUEST, CommonUtils.getString(employeeSearchRequest)));
		EmployeeSearchResponse employeeSearchResponse = null;
		employeeSearchResponse = employeeService.findAllEmployeeDetails(employeeSearchRequest);
		if (employeeSearchResponse != null) {
			return new ResponseEntity<EmployeeSearchResponse>(employeeSearchResponse, HttpStatus.OK);
		} else {
			LOGGER.info(String.format(ServiceConstraint.RESPONSE, CommonUtils.getString(employeeSearchResponse)));
			return new ResponseEntity<EmployeeSearchResponse>(HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping("delete/{empId}")
	public ResponseEntity<String> deleteEmployeeDetails(@PathVariable int empId,
			HttpServletRequest httpServletRequest) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));
		LOGGER.info(String.format(ServiceConstraint.REQUEST, CommonUtils.getString(empId)));
		try {
			boolean flag = employeeService.deleteEmployeeById(empId);
			if (flag) {
				return ResponseEntity.ok(SuccessMessages.EMPLOYEE_DETAILS_DELETED_SUCCESSFULLY);
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorMessages.SOMETHING_WENT_WRONG);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorMessages.SOMETHING_WENT_WRONG);
		}
	}

	@GetMapping("find/laptop/{empId}")
	public ResponseEntity<LaptopResponse> getLaptopDetails(@PathVariable("empId") int empId,
			HttpServletRequest httpServletRequest) {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));
		LOGGER.info(String.format(ServiceConstraint.REQUEST, CommonUtils.getString(empId)));
		LaptopResponse laptopResponse = null;
		laptopResponse = employeeService.retrieveLaptopDetails(empId);
		if (CommonUtils.isNotEmpty(laptopResponse.getLaptopResponseList())) {
			return new ResponseEntity<LaptopResponse>(laptopResponse, HttpStatus.OK);
		} else {
			LOGGER.info(String.format(ServiceConstraint.RESPONSE, CommonUtils.getString(laptopResponse)));
			return new ResponseEntity<LaptopResponse>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("sendemail")
	public ResponseEntity<String> sendMail(HttpServletRequest httpServletRequest,
			@RequestPart EmployeeEmailRequest employeeEmailRequest,@RequestPart MultipartFile [] multipartFile ) 
					throws MessagingException {
		LOGGER.info(String.format(ServiceConstraint.REQUEST_URL,
				CommonUtils.getString(httpServletRequest.getRequestURI())));
		try {
			employeeService.sendEmail(employeeEmailRequest,multipartFile);
			return ResponseEntity.status(HttpStatus.OK).body(SuccessMessages.MAIL_SEND_SUCCESSFULLY);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorMessages.SOMETHING_WENT_WRONG);
		}
	}

	
	
}
