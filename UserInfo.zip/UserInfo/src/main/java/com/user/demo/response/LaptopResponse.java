package com.user.demo.response;

import java.util.List;

public class LaptopResponse {
	private int empId;
	private List<LaptopResponseList> laptopResponseList;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public List<LaptopResponseList> getLaptopResponseList() {
		return laptopResponseList;
	}

	public void setLaptopResponseList(List<LaptopResponseList> laptopResponseList) {
		this.laptopResponseList = laptopResponseList;
	}

	@Override
	public String toString() {
		return "LaptopResponse [empId=" + empId + ", laptopResponseList=" + laptopResponseList + "]";
	}

}
