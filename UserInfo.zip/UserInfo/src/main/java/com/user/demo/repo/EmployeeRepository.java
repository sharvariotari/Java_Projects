package com.user.demo.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.user.demo.domain.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	Optional<Employee> findByEmpId(int empId);
	
	Optional<Employee> findByEmpIdOrEmployeeName(int empId, String employeeName);

	Optional<Employee> findByEmpId(Long empId);

	
	
}
