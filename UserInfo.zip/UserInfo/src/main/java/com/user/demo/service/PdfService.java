package com.user.demo.service;

import java.io.ByteArrayInputStream;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.user.demo.request.PdfRequest;
@Service
public interface PdfService {
	 public ByteArrayInputStream createPdf();

	public Boolean generatePdfFile(PdfRequest pdfRequest);

	public Boolean readFileData(MultipartFile multipartFile);

	public void convertToPdf(PdfRequest pdfRequest);
}
