package com.user.demo.request;

import java.util.List;

public class EmployeeLaptopMappingListRequest {
	
private List<LaptopRequest> laptopReqList;

public List<LaptopRequest> getLaptopReqList() {
	return laptopReqList;
}

public void setLaptopReqList(List<LaptopRequest> laptopReqList) {
	this.laptopReqList = laptopReqList;
}

@Override
public String toString() {
	return "EmployeeLaptopMappingListRequest [laptopReqList=" + laptopReqList + "]";
}


}
